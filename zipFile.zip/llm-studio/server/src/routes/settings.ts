import { Router } from "express";
import { z } from "zod";
import { db, settings, SETTINGS_ROW_ID } from "../db.js";
import { invalidateKeyCache, resolveApiKey } from "../lib/openrouter.js";

const router = Router();

const UpdateSettingsBody = z.object({ openrouterApiKey: z.string() });

function maskKey(key: string): string {
  return `sk-or-…${key.slice(-4)}`;
}

async function buildStatus() {
  const { key, source } = await resolveApiKey();
  return { hasKey: Boolean(key), keyPreview: key ? maskKey(key) : null, source };
}

async function setKey(key: string | null) {
  await db
    .insert(settings)
    .values({ id: SETTINGS_ROW_ID, openrouterApiKey: key })
    .onConflictDoUpdate({ target: settings.id, set: { openrouterApiKey: key, updatedAt: new Date() } });
  invalidateKeyCache();
}

router.get("/settings", async (_req, res) => {
  res.json(await buildStatus());
});

router.put("/settings", async (req, res) => {
  const body = UpdateSettingsBody.parse(req.body);
  const key = body.openrouterApiKey.trim();
  if (!key) { res.status(400).json({ error: "API key cannot be empty" }); return; }
  await setKey(key);
  res.json(await buildStatus());
});

router.delete("/settings", async (_req, res) => {
  await setKey(null);
  res.json(await buildStatus());
});

export default router;
