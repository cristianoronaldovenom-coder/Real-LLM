import { Router } from "express";
import { z } from "zod";
import { db, conversations, messages } from "../db.js";
import { asc, desc, eq } from "drizzle-orm";
import { getOpenRouterClient, MissingApiKeyError } from "../lib/openrouter.js";
import { normalizeModel } from "../lib/models.js";
import { buildContextBlock, retrieveRelevantChunks } from "../lib/rag.js";
import { buildMemoryBlock, getAllMemories, learnFromExchange } from "../lib/memory.js";

const router = Router();

const CreateConversationBody = z.object({
  title: z.string().optional(),
  model: z.string().optional(),
  systemPrompt: z.string().optional(),
  useKnowledgeBase: z.boolean().optional(),
});

const UpdateConversationBody = z.object({
  title: z.string().optional(),
  model: z.string().optional(),
  systemPrompt: z.string().optional().nullable(),
  useKnowledgeBase: z.boolean().optional(),
});

const SendMessageBody = z.object({ content: z.string().min(1) });

router.get("/conversations", async (_req, res) => {
  const rows = await db.select().from(conversations).orderBy(desc(conversations.createdAt));
  res.json(rows);
});

router.post("/conversations", async (req, res) => {
  const body = CreateConversationBody.parse(req.body);
  const model = normalizeModel(body.model);
  const [created] = await db
    .insert(conversations)
    .values({ title: body.title ?? "New Conversation", model, systemPrompt: body.systemPrompt ?? null, useKnowledgeBase: body.useKnowledgeBase ?? false })
    .returning();
  res.status(201).json(created);
});

router.get("/conversations/:id", async (req, res) => {
  const id = Number(req.params.id);
  const [convo] = await db.select().from(conversations).where(eq(conversations.id, id));
  if (!convo) { res.status(404).json({ error: "Conversation not found" }); return; }
  const msgs = await db.select().from(messages).where(eq(messages.conversationId, id)).orderBy(asc(messages.createdAt), asc(messages.id));
  res.json({ ...convo, messages: msgs });
});

router.patch("/conversations/:id", async (req, res) => {
  const id = Number(req.params.id);
  const body = UpdateConversationBody.parse(req.body);
  const updates: Record<string, unknown> = {};
  if (body.title !== undefined) updates.title = body.title;
  if (body.model !== undefined) updates.model = normalizeModel(body.model);
  if (body.systemPrompt !== undefined) updates.systemPrompt = body.systemPrompt;
  if (body.useKnowledgeBase !== undefined) updates.useKnowledgeBase = body.useKnowledgeBase;

  if (Object.keys(updates).length === 0) {
    const [convo] = await db.select().from(conversations).where(eq(conversations.id, id));
    if (!convo) { res.status(404).json({ error: "Conversation not found" }); return; }
    res.json(convo); return;
  }
  updates.updatedAt = new Date();
  const [updated] = await db.update(conversations).set(updates).where(eq(conversations.id, id)).returning();
  if (!updated) { res.status(404).json({ error: "Conversation not found" }); return; }
  res.json(updated);
});

router.delete("/conversations/:id", async (req, res) => {
  const id = Number(req.params.id);
  const [deleted] = await db.delete(conversations).where(eq(conversations.id, id)).returning({ id: conversations.id });
  if (!deleted) { res.status(404).json({ error: "Conversation not found" }); return; }
  res.status(204).end();
});

router.get("/conversations/:id/messages", async (req, res) => {
  const id = Number(req.params.id);
  const msgs = await db.select().from(messages).where(eq(messages.conversationId, id)).orderBy(asc(messages.createdAt), asc(messages.id));
  res.json(msgs);
});

router.post("/conversations/:id/messages", async (req, res) => {
  const id = Number(req.params.id);
  const body = SendMessageBody.parse(req.body);

  const [convo] = await db.select().from(conversations).where(eq(conversations.id, id));
  if (!convo) { res.status(404).json({ error: "Conversation not found" }); return; }

  const history = await db.select().from(messages).where(eq(messages.conversationId, id)).orderBy(asc(messages.createdAt), asc(messages.id));

  await db.insert(messages).values({ conversationId: id, role: "user", content: body.content });

  if (history.length === 0) {
    const title = body.content.replace(/\s+/g, " ").trim().slice(0, 60);
    if (title) await db.update(conversations).set({ title }).where(eq(conversations.id, id));
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  const send = (payload: Record<string, unknown>) => res.write(`data: ${JSON.stringify(payload)}\n\n`);

  const controller = new AbortController();
  let clientGone = false;
  req.on("close", () => { clientGone = true; controller.abort(); });

  try {
    const chatMessages: { role: "system" | "user" | "assistant"; content: string }[] = [];

    let systemContent = convo.systemPrompt?.trim() || "You are a helpful, knowledgeable assistant.";

    const memoryItems = await getAllMemories();
    const memoryBlock = buildMemoryBlock(memoryItems);
    if (memoryBlock) systemContent += "\n\n" + memoryBlock;

    if (convo.useKnowledgeBase) {
      const chunks = await retrieveRelevantChunks(body.content);
      if (chunks.length > 0) {
        systemContent +=
          "\n\nUse the following information from the user's knowledge base to answer when relevant. " +
          "If the answer is not contained in it, rely on your own knowledge and say so.\n\n" +
          buildContextBlock(chunks);
      }
    }

    chatMessages.push({ role: "system", content: systemContent });
    for (const m of history) {
      if (m.role === "user" || m.role === "assistant") chatMessages.push({ role: m.role as "user" | "assistant", content: m.content });
    }
    chatMessages.push({ role: "user", content: body.content });

    const client = await getOpenRouterClient();
    const stream = await client.chat.completions.create(
      { model: convo.model, messages: chatMessages, stream: true, max_tokens: 8192 },
      { signal: controller.signal }
    );

    let full = "";
    for await (const part of stream) {
      if (clientGone) break;
      const delta = part.choices[0]?.delta?.content;
      if (delta) { full += delta; send({ delta }); }
    }

    if (clientGone) {
      if (full) await db.insert(messages).values({ conversationId: id, role: "assistant", content: full });
      return;
    }

    await db.insert(messages).values({ conversationId: id, role: "assistant", content: full });
    res.write("data: [DONE]\n\n");
    res.end();

    if (full.trim()) void learnFromExchange(body.content, full);
  } catch (err) {
    if (clientGone) return;
    if (err instanceof MissingApiKeyError) {
      send({ error: err.message });
      res.write("data: [DONE]\n\n");
      res.end();
      return;
    }
    console.error("Chat stream error:", err);
    send({ error: "Something went wrong while generating a response. Please try again." });
    res.write("data: [DONE]\n\n");
    res.end();
  }
});

export default router;
