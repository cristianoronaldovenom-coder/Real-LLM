import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import systemRouter from "./routes/index.js";
import conversationsRouter from "./routes/conversations.js";
import documentsRouter from "./routes/documents.js";
import memoriesRouter from "./routes/memories.js";
import settingsRouter from "./routes/settings.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();

app.use(cors());
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

// API routes
app.use("/api", systemRouter);
app.use("/api", conversationsRouter);
app.use("/api", documentsRouter);
app.use("/api", memoriesRouter);
app.use("/api", settingsRouter);

// Serve built frontend in production
const clientDist = path.resolve(__dirname, "../../client/dist");
app.use(express.static(clientDist));
app.get("*", (_req, res) => {
  res.sendFile(path.join(clientDist, "index.html"));
});

export default app;
